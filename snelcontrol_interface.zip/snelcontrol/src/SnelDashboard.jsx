import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { motion } from "framer-motion";

const initialClients = [
  { id: 1, nom: "Client A", zone: "Gombe", actif: true },
  { id: 2, nom: "Client B", zone: "Kintambo", actif: false },
  { id: 3, nom: "Client C", zone: "Matete", actif: true },
];

export default function SnelDashboard() {
  const [clients, setClients] = useState(initialClients);

  const toggleElectricity = (id) => {
    setClients((prev) =>
      prev.map((client) =>
        client.id === id ? { ...client, actif: !client.actif } : client
      )
    );
  };

  return (
    <main className="p-6 max-w-5xl mx-auto">
      <motion.h1
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-3xl font-bold mb-6"
      >
        SNELControl RDC - Tableau de Bord Électrique
      </motion.h1>

      <div className="grid md:grid-cols-3 gap-4">
        {clients.map((client) => (
          <Card key={client.id} className="rounded-2xl shadow">
            <CardContent className="p-4 space-y-2">
              <h2 className="text-xl font-semibold">{client.nom}</h2>
              <p className="text-gray-600">Zone : {client.zone}</p>
              <div className="flex items-center justify-between">
                <span className={\`text-sm font-medium \${client.actif ? 'text-green-600' : 'text-red-600'}\`}>
                  {client.actif ? "Alimenté" : "Coupé"}
                </span>
                <Switch checked={client.actif} onCheckedChange={() => toggleElectricity(client.id)} />
              </div>
              <Button
                variant={client.actif ? "destructive" : "default"}
                onClick={() => toggleElectricity(client.id)}
              >
                {client.actif ? "Couper" : "Rétablir"} l’électricité
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </main>
  );
}
